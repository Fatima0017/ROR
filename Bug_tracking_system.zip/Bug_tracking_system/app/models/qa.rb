class Qa < User
  has_many :bugs
end
