class Manager < User
  has_many :projects
end