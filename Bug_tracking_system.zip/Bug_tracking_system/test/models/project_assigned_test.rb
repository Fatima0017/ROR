require "test_helper"

class ProjectAssignedTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
